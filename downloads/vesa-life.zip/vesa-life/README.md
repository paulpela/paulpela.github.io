# README

This binary image can be run directly on any suitable machine, including
emulators.

I suggest using VirtualBox for this.

## How to use this with VirtualBox

1. Create a new machine with no disks and 64MB of RAM.
2. Add a floppy controller.
3. Attach the floppy image to this controller.
4. Set the machine to boot from floppy.
5. Run it!

## Acknowlegements

This binary image incorporates Pure64
(https://github.com/ReturnInfinity/Pure64) by Ian Seyler to set up a clean 
x86_64 environment in a great way. Check the Pure64-LICENSE.txt for 
details. Also, go to http://returninfinity.com/ for some great ideas on 
software and Operating Systems!

